//
//  ViewController.m
//  OpenGLES_draw_triangle
//
//  Created by xu jie on 16/8/1.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
