//
//  AppDelegate.h
//  OpenGLES_draw_triangle
//
//  Created by xu jie on 16/8/1.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

