//
//  ViewController.h
//  OpenGLES_texture
//
//  Created by xu jie on 16/8/22.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>
@interface ViewController : GLKViewController


@end

