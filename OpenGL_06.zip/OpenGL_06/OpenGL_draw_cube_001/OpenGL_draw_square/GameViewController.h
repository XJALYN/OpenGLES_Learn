//
//  GameViewController.h
//  OpenGL_draw_square
//
//  Created by xu jie on 16/8/4.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface GameViewController : GLKViewController

@end
