//
//  AppDelegate.h
//  OpenGLES_008
//
//  Created by xu jie on 16/8/9.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

