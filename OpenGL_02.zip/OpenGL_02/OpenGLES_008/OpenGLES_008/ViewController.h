//
//  ViewController.h
//  OpenGLES_008
//
//  Created by xu jie on 16/8/9.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

@interface ViewController : GLKViewController


@end

